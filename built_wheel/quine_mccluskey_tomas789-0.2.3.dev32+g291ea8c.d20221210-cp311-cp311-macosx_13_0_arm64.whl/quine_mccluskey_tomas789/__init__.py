"""A Python implementation of the Quine McCluskey algorithm."""
print("FILE", __file__)
from .qm import simplify, simplify_los